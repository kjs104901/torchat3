# torchat3 [Developing]
Electron-based torchat

## Requirements

node.js: https://nodejs.org

## Installation

```
git clone https://github.com/kjs104901/torchat3.git torchat3
cd torchat3
npm install
./node_modules/.bin/electron-rebuild
```

## Usage

```
npm run sandbox
```